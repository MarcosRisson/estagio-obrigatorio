<div class="container-fluid">
    <form action="" method="post" class="my-1">
        <div class="msg"></div>
        <div class="row">
            <div class="col-md-5">
                <div class="form-group">
                    <div class="form-group">
                        <label for="documento_fornecedor">Documento:</label>
                        <div class="input-group">
                            <input class="form-control" type="text" id="documento_fornecedor"
                                ng-model="item.documento_fornecedor" required>
                            <button type="button" class="btn btn-primary" ng-click="fazerRequisicao()">
                                <span class="ng-confirm-btn-text">Fazer Requisição</span>
                            </button>

                        </div>
                    </div>

                </div>
            </div>
            <div class="col-md-7">
                <div class="form-group">
                    <label for="nome_fornecedor">Fornecedor:</label>
                    <input class="form-control" type="text" id="nome_fornecedor" ng-model="item.nome_fornecedor"
                        required>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label for="razao_social">Razão Social:</label>
                    <input class="form-control" type="text" id="razao_social" ng-model="item.razao_social" required>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label for="nome_fantasia">Nome Fantasia:</label>
                    <input class="form-control" type="text" id="nome_fantasia" ng-model="item.nome_fantasia" required>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="cep">CEP:</label>
                    <input class="form-control" type="text" id="cep" ng-model="item.cep" required>
                </div>
            </div>
            <div class="col-md-8">
                <div class="form-group">
                    <label for="endereco">Endereço:</label>
                    <input class="form-control" type="text" id="endereco" ng-model="item.endereco" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="bairro">Bairro:</label>
                    <input class="form-control" type="text" id="bairro" ng-model="item.bairro" required>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="cidade">Cidade:</label>
                    <input class="form-control" type="text" id="cidade" ng-model="item.cidade" required>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label for="uf">UF:</label>
                    <input class="form-control" type="text" id="uf" ng-model="item.uf" required>
                </div>
            </div>

        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="email_fornecedor">Email:</label>
                    <input class="form-control" type="text" id="email_fornecedor" ng-model="item.email_fornecedor"
                        required>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="telefone">Telefone:</label>
                    <input class="form-control" type="text" id="telefone" ng-model="item.telefone" required>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label for="status_fornecedor">Status:</label>
                    <select id="status_fornecedor" name="status_fornecedor" class="form-control"
                        ng-model="item.status_fornecedor" required>
                        <option value="" disabled selected>Selecione</option>
                        <option value='Ativo'>Ativo</option>
                        <option value='Desativado'>Desativado</option>
                    </select>
                </div>
            </div>
        </div>
    </form>
</div>