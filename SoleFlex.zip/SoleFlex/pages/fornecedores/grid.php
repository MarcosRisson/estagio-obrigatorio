<div class="row">
    <div class="col-md-6">
        <h3 class="h3 mb-4 text-gray-800">Lista de Fornecedores</h3>
    </div>
    
    <div class="col-md-6 text-right">
        <button class="btn btn-info" ng-click="generatePDF()">Relatório</button>
        <button class="btn btn-success" ng-click="send('add')">Cadastrar Novo</button>
    </div>
</div>

<div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <select class="form-control" ng-model="filtroTipo" ng-change="filter(filtroTipo)">
                    <option value="sem-filtro">Sem Filtro</option>
                    <option value='Ativo'>Ativo</option>
                    <option value='Desativado'>Desativado</option>
                </select>
    
            </div>
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                      
                        <th>NOME</th>
                        <th>E-MAIL</th>
                        <th>CIDADE</th>
                        <th>DOCUMENTO</th>
                        <th>STATUS</th>
                        <th class="notPrint printConf">AÇOES</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <tr ng-repeat="x in grid " >
                      
                        <td>{{x.nome_fornecedor}}</td>
                        <td>{{x.email_fornecedor}}</td>
                        <td>{{x.cidade}}</td>
                        <td>{{x.documento_fornecedor}}</td>
                        <td>{{x.status_fornecedor}}</td>
                     
                        <td class="notPrint printConf">
                            <button class="btn btn-primary btn-sm "  ng-click="send($index, x)">Editar</button>
                            <button class="btn btn-danger btn-sm " ng-click="del($index, x)">Deletar</button>
                            <button class="btn btn-info btn-sm " ng-click="toggleDetails(x)">Detalhes</button>
                            
                        </td>
                        
                    </tr>
                    <tr ng-show="showDetailsForm && angular.equals(selectedFornecedor, x)">
                        <h3 class="h3 mb-4 text-gray-800">Detalhes do Fornecedor</h3>
                        <td colspan="5" class="notPrint printConf">
                            <div class="card shadow mb-4 ">
                                <button class="btn btn-secondary btn-sm" ng-click="toggleDetails(selectedFornecedor)">Fechar Detalhes</button>
                                <div class="card-body">
                                    <!-- Detalhes do fornecedor aqui -->
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
                
            </table>
        </div>
    </div>
</div>

<div ng-show="showDetailsForm">
    
    <div class="card shadow mb-4">
        <button class="btn btn-secondary btn-sm" ng-click="toggleDetails(selectedFornecedor)">Fechar
                Detalhes </button>
        <div class="card-body">
              
            <form>
                <div class="row">
                    <div class="mb-3 col-md-1">
                        <label for="status">Status:</label>
                        <input type="text" class="form-control" id="status"
                            ng-model="selectedFornecedor.status_fornecedor" readonly>
                    </div>
                    <div class="mb-3 col-md-5">
                        <label for="nome_fornecedor">Nome:</label>
                        <input type="text" class="form-control" id="nome_fornecedor" ng-model="selectedFornecedor.nome_fornecedor"
                            readonly>
                    </div>
                    

                    <div class="mb-3 col-md-2">
                        <label for="documento">Documento:</label>
                        <input type="text" class="form-control" id="documento"
                            ng-model="selectedFornecedor.documento_fornecedor" readonly>
                    </div>
                    <div class="mb-3 col-md-4">
                        <label for="email">E-mail:</label>
                        <input type="text" class="form-control" id="email"
                            ng-model="selectedFornecedor.email_fornecedor" readonly>
                    </div>
                    
                    <div class="mb-3 col-md-5">
                        <label for="razao_social">Razão Social:</label>
                        <input type="text" class="form-control" id="razao_social" ng-model="selectedFornecedor.razao_social"
                            readonly>
                    </div>

                    <div class="mb-3 col-md-4">
                        <label for="nome_fantasia">Nome Fantasia:</label>
                        <input type="text" class="form-control" id="nome_fantasia" ng-model="selectedFornecedor.nome_fantasia"
                            readonly>
                    </div>
                    <div class="mb-3 col-md-3">
                        <label for="telefone">Telefone:</label>
                        <input type="text" class="form-control" id="telefone" ng-model="selectedFornecedor.telefone"
                            readonly>
                    </div>
                    <div class="mb-3 col-md-3">
                        <label for="cep">CEP:</label>
                        <input type="text" class="form-control" id="cep" ng-model="selectedFornecedor.cep" readonly>
                    </div>
                    <div class="mb-3 col-md-9">
                        <label for="endereco">Endereço:</label>
                        <input type="text" class="form-control" id="endereco" ng-model="selectedFornecedor.endereco"
                            readonly>
                    </div>
                    <div class="mb-3 col-md-6">
                        <label for="bairro">Bairro:</label>
                        <input type="text" class="form-control" id="bairro" ng-model="selectedFornecedor.bairro"
                            readonly>
                    </div>

                    <div class="mb-3 col-md-5">
                        <label for="cidade">Cidade:</label>
                        <input type="text" class="form-control" id="cidade" ng-model="selectedFornecedor.cidade"
                            readonly>
                    </div>
                    <div class="mb-3 col-md-1">
                        <label for="uf">UF:</label>
                        <input type="text" class="form-control" id="uf" ng-model="selectedFornecedor.uf" readonly>
                    </div>
                   




                </div>
            </form>
          
        </div>
    </div>
</div>