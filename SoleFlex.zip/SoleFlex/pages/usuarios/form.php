<form action="" method="post">
<div class="msg"></div>
<label>Nome:</label>
<input class="form-control" type="text" ng-model="item.name">
<label>Email:</label>
<input class="form-control" type="text" ng-model="item.email">
<label>Senha:</label>
<input class="form-control" type="password" ng-model="item.password">
</form>
<div class="form-row mb-3">
    <div class="col-md-6">
        <div class="form-group">
            <label for="status_produto">Status:</label>
            <select id="status_produto" name="status_produto" class="form-control" ng-model="item.status_usuario" required>
                <option value='Ativo'>Ativo</option>
                <option value='Desativado'>Desativado</option>
            </select>
        </div>
    </div>
</div>
