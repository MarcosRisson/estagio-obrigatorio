<div class="row">
    <div class="col-md-6">
        <h3 class="mb-3">Lista de Usuários</h3>
    </div>
    <div class="col-md-6 text-right">
        <button class="btn btn-success" ng-click="send('add')">Cadastrar Novo</button>
    </div>
</div>
</div>

<div class="card mt-3">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>NOME</th>
                        <th>E-MAIL</th>
                        <th>STATUS</th>
                        <th>AÇÕES</th>
                    </tr>
                </thead>
                <tbody>
                    <tr ng-repeat="x in grid">
                        <td>{{x.name}}</td>
                        <td>{{x.email}}</td>
                        <td>{{x.status_usuario}}</td>
                        <td>
                            <button class="btn btn-info btn-sm" ng-click="send($index, x)">Editar</button>
                            <button class="btn btn-danger btn-sm" ng-click="del($index, x)">Deletar</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
