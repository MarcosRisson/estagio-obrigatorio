<?php
include '../../api/private/connect.php';

$estoqueQuery = $mysqli->query("SELECT * FROM `estoque` INNER JOIN produtos ON estoque.produto_estoque_fk = produtos.produto_id
INNER JOIN fornecedores ON produtos.fornecedor_produto_fk = fornecedores.id");

?>
<div class="row">
    <div class="col-md-6">
        <h3 class="h3 mb-4 text-gray-800">Estoque</h3>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>FORNECEDOR</th>
                        <th>PRODUTO</th>
                        <th>COR</th>
                        <th>TAMANHO</th>
                        <th>MARCA</th>
                        <th>MODELO</th>
                        <th>VALOR</th>
                        <th>QUANTIDADE</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $estoqueQuery->fetch_assoc()) { ?>
                        <tr>
                            <td class="text-left"><?php echo $row['nome_fornecedor']; ?></td>
                            <td class="text-left"><?php echo $row['nome_produto']; ?></td>
                            <td class="text-left"><?php echo $row['cor_produto']; ?></td>
                            <td class="text-right"><?php echo $row['tamanho_produto']; ?></td>
                            <td class="text-left"><?php echo $row['marca_produto']; ?></td>
                            <td class="text-left"><?php echo $row['modelo_produto']; ?></td>
                            <td class="text-right">R$<?php echo number_format($row['preco_produto'], 2, ',', '.'); ?></td>
                            <td class="text-right"><?php echo $row['quantidade_estoque']; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
