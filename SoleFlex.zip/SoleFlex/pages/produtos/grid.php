<?php
include '../../api/private/connect.php';

$fornecedoresQuery = $mysqli->query("SELECT * FROM `fornecedores` ORDER BY `nome_fornecedor` ASC");
$fornecedores = $fornecedoresQuery->fetch_all(PDO::FETCH_ASSOC);
?>

<div class="row">
    <div class="col-md-6">
        <h3 class="h3 mb-4 text-gray-800">Lista de Produtos</h3>
    </div>
    
    <div class="col-md-6 text-right">
        <button class="btn btn-info" ng-click="generatePDF()">Relatório</button>
        <button class="btn btn-success" ng-click="send('add')">Cadastrar Novo</button>
    </div>
</div>
<div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <select class="form-control" ng-model="filtroTipo" ng-change="filter(filtroTipo)">
                    <option value="sem-filtro">Sem Filtro</option>
                    <option value='Ativo'>Ativo</option>
                    <option value='Desativado'>Desativado</option>
                </select>
    
            </div>
        </div>
</div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>FORNECEDOR</th>
                            <th>PRODUTO</th>
                            <th>COR</th>
                            <th>TAMANHO</th>
                            <th>MARCA</th>
                            <th>MODELO</th>
                            <th>VALOR</th>
                            <th class="notPrint printConf">AÇÕES</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr ng-repeat="x in grid">
                            <td class="text-right">{{x.fornecedor_produto_fk}}</td>
                            <td>{{x.nome_produto}}</td>
                            <td>{{x.cor_produto}}</td>
                            <td class="text-right">{{x.tamanho_produto}}</td>
                            <td>{{x.marca_produto}}</td>
                            <td>{{x.modelo_produto}}</td>
                            <td class="text-right" >{{formatarPreco(x.preco_produto)}}</td>
                            <td class="notPrint printConf">
                                <button class="btn btn-primary btn-sm" ng-click="send($index, x)">Editar</button>
                                <button class="btn btn-danger btn-sm" ng-click="del($index, x)">Deletar</button>
                                <button class="btn btn-info btn-sm" ng-click="toggleDetails(x)">Detalhes</button>

                            </td>

                        </tr>
                        <tr ng-show="showDetailsForm && angular.equals(selectedProduct, x)">
                            <h3 class="h3 mb-4 text-gray-800">Detalhes do Produto</h3>
                            <td colspan="5" class="notPrint printConf">
                                <div class="card shadow mb-4">
                                    <button class="btn btn-secondary btn-sm" ng-click="toggleDetails(selectedProduct)">Fechar Detalhes</button>
                                    <div class="card-body">
                                        <!-- Detalhes do fornecedor aqui -->
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>

                </table>
            </div>
        </div>
    </div>

    <div ng-show="showDetailsForm">

<div class="card shadow mb-4">
    <button class="btn btn-secondary btn-sm" ng-click="toggleDetails(selectedProduct)">Fechar
        Detalhes </button>
    <div class="card-body">

        <form>
            <div class="row">
                <div class="mb-3 col-md-1">
                    <label for="status">Status:</label>
                    <input type="text" class="form-control" id="status" ng-model="selectedProduct.status_produto" readonly>
                </div>
                <div class="mb-3 col-md-5">
                    <label for="nome">Nome do Produto:</label>
                    <input type="text" class="form-control" id="nome" ng-model="selectedProduct.nome_produto" readonly>
                </div>

               <div class="mb-3 col-md-2">
                    <label for="cor">Cor:</label>
                    <input type="text" class="form-control" id="cor" ng-model="selectedProduct.cor_produto" readonly>
                </div>
            </div>
            <div class="row">
                <div class="mb-3 col-md-1">
                    <label for="tamanho">Tamanho:</label>
                    <input type="text" class="form-control" id="tamanho" ng-model="selectedProduct.tamanho_produto" readonly>
                </div>

                <div class="mb-3 col-md-2">
                    <label for="marca">Marca:</label>
                    <input type="text" class="form-control" id="marca" ng-model="selectedProduct.marca_produto" readonly>
                </div>
                <div class="mb-3 col-md-2">
                    <label for="modelo">Modelo:</label>
                    <input type="text" class="form-control" id="modelo" ng-model="selectedProduct.modelo_produto" readonly>
                </div>
                <div class="mb-3 col-md-2">
                    <label for="valor">Preço:</label>
                    <input type="text" class="form-control" id="preco" ng-model="selectedProduct.preco_produto" readonly>
                </div>

            </div>
        </form>

    </div>
</div>
</div>