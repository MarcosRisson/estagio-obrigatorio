<?php
include '../../api/private/connect.php';

$fornecedoresQuery = $mysqli->query("SELECT * FROM `fornecedores` ORDER BY `nome_fornecedor` ASC");
$fornecedores = $fornecedoresQuery->fetch_all(PDO::FETCH_ASSOC);
?>

<div class="row">
    <div class="col-md-6">
        <h3 class="h3 mb-4 text-gray-800">Lista de Produtos</h3>
    </div>
    
    <div class="col-md-6 text-right">
        <button class="btn btn-info" ng-click="generatePDF()">Relatório</button>
        <button class="btn btn-success" ng-click="send('add')">Cadastrar Novo</button>
    </div>
</div>
<div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <select class="form-control" ng-model="filtroTipo" ng-change="filter(filtroTipo)">
                    <option value="sem-filtro">Sem Filtro</option>
                    <option value='1'>Ativo</option>
                    <option value='0'>Desativado</option>
                </select>
    
            </div>
        </div>
</div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>FORNECEDOR</th>
                            <th>PRODUTO</th>
                            <th>COR</th>
                            <th>TAMANHO</th>
                            <th>MARCA</th>
                            <th>MODELO</th>
                            <th>VALOR</th>

                            <th>AÇÕES</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr ng-repeat="x in grid">
                            <td>{{x.fornecedor_produto_fk}}</td>
                            <td>{{x.nome_produto}}</td>
                            <td>{{x.cor_produto}}</td>
                            <td>{{x.tamanho_produto}}</td>
                            <td>{{x.marca_produto}}</td>
                            <td>{{x.modelo_produto}}</td>
                            <td>{{formatarPreco(x.preco_produto)}}</td>
                            <td>
                                <button class="btn btn-primary btn-sm" ng-click="send($index, x)">Editar</button>
                                <button class="btn btn-danger btn-sm" ng-click="del($index, x)">Deletar</button>
                                <button class="btn btn-info btn-sm" ng-click="toggleDetails(x)">Detalhes</button>

                            </td>

                        </tr>
                        <tr ng-show="showDetailsForm && angular.equals(selectedProduct, x)">
                            <h3 class="h3 mb-4 text-gray-800">Detalhes do Produto</h3>
                            <td colspan="5">
                                <div class="card shadow mb-4">
                                    <button class="btn btn-secondary btn-sm" ng-click="toggleDetails(selectedProduct)">Fechar Detalhes</button>
                                    <div class="card-body">
                                        <!-- Detalhes do fornecedor aqui -->
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>

                </table>
            </div>
        </div>
    </div>

    <div ng-show="showDetailsForm">

        <div class="card shadow mb-4">
            <button class="btn btn-secondary btn-sm" ng-click="toggleDetails(selectedProduct)">Fechar
                Detalhes </button>
            <div class="card-body">

                <form>
                    <div class="row">
                        <div class="mb-3 col-md-1">
                            <label for="status">Status:</label>
                            <input type="text" class="form-control" id="status" ng-model="selectedProduct.fornecedor_fk" readonly>
                        </div>
                        <div class="mb-3 col-md-5">
                            <label for="nome">Nome:</label>
                            <input type="text" class="form-control" id="nome" ng-model="selectedProduct.nome_fornecedor" readonly>
                        </div>


                        <div class="mb-3 col-md-2">
                            <label for="documento">Documento:</label>
                            <input type="text" class="form-control" id="documento" ng-model="selectedProduct.documento_fornecedor" readonly>
                        </div>
                        <div class="mb-3 col-md-4">
                            <label for="email">E-mail:</label>
                            <input type="text" class="form-control" id="e   mail" ng-model="selectedFornecedor.email_fornecedor" readonly>
                        </div>

                        <div class="mb-3 col-md-5">
                            <label for="nome">Razão Social:</label>
                            <input type="text" class="form-control" id="nome" ng-model="selectedFornecedor.razao_social" readonly>
                        </div>

                    </div>
                </form>

            </div>
        </div>
    </div>