<?php
include '../../api/private/connect.php';

$fornecedoresQuery = $mysqli->query("SELECT * FROM `fornecedores` ORDER BY `nome_fornecedor` ASC");
$fornecedores = $fornecedoresQuery->fetch_all(PDO::FETCH_ASSOC);
?>

<div class="container-fluid" style="max-width: 1200px;">
    <form method="POST" class="mx-auto">

        <div class="form-group">
            <label for="fornecedor_produto_fk">Fornecedor:</label>
            <select id="fornecedor_produto_fk" name="fornecedor_produto_fk" class="form-control" ng-model="item.fornecedor_produto_fk" required>
                <?php foreach ($fornecedores as $fornecedor) { ?>
                    <option value="<?php echo $fornecedor['0']; ?>"><?php echo $fornecedor['0']; ?> - <?php echo $fornecedor['3']; ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="form-row mb-3">
            <div class="form-group col-md-6">
                <label for="produto" class="col-form-label col-md-4">Produto:</label>
                <input class="form-control" type="text" id="produto" ng-model="item.nome_produto" required>
            </div>

            <div class="form-group col-md-6">
                <label for="cor" class="col-form-label col-md-2">Cor:</label>
                <input class="form-control" type="text" id="cor" ng-model="item.cor_produto" required>
            </div>
        </div>

        <div class="form-row mb-3">
            <div class="form-group col-md-6">
                <label for="tamanho" class="col-form-label col-md-6">Tamanho:</label>
                <input class="form-control" type="text" id="tamanho" ng-model="item.tamanho_produto" required>
            </div>

            <div class="form-group col-md-6">
                <label for="marca" class="col-form-label col-md-6">Marca:</label>
                <input class="form-control" type="text" id="marca" ng-model="item.marca_produto" required>
            </div>
        </div>

        <div class="form-row mb-3">
            <div class="form-group col-md-6">
                <label for="modelo" class="col-form-label col-md-4">Modelo:</label>
                <input class="form-control" type="text" id="modelo" ng-model="item.modelo_produto" required>
            </div>

            <div class="form-group col-md-6">
                <label for="preco" class="col-form-label col-md-2">Preço:</label>
                <input class="form-control" type="text" id="preco" ng-model="item.preco_produto" required>
            </div>
        </div>

        <div class="form-row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="status_produto">Status:</label>
                    <select id="status_produto" name="status_produto" class="form-control" ng-model="item.status_produto" required>
                        <option value='1'>Ativo</option>
                        <option value='0'>Desativado</option>
                    </select>
                </div>
            </div>
        </div>
    </form>
</div>