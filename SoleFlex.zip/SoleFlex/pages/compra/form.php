<?php
include '../../api/private/connect.php';

$fornecedoresQuery = $mysqli->query("SELECT * FROM `fornecedores` ORDER BY `nome_fornecedor` ASC");
$fornecedores = $fornecedoresQuery->fetch_all(PDO::FETCH_ASSOC);

$produtosQuery = $mysqli->query("SELECT * FROM `produtos` ORDER BY `nome_produto` ASC");
$produtos = $produtosQuery->fetch_all(PDO::FETCH_ASSOC);
?>


<div class="container-fluid" style="max-width: 1200px;" ng-app="myApp">
    <form method="POST" class="mx-auto">
        <div class="msg"></div>
        <div class="form-group">
            <label for="fornecedor_produto_fk">Fornecedor:</label>
            <select id="fornecedor_produto_fk" name="fornecedor_produto_fk" class="form-control" ng-model="item.fornecedor_produto_fk" required>
                <?php foreach ($fornecedores as $fornecedor) { ?>
                    <option value="<?php echo $fornecedor['0']; ?>"><?php echo $fornecedor['0']; ?> - <?php echo $fornecedor['3']; ?></option>
                <?php } ?>
            </select>
        </div>

    

        <div id="selectContents" ng-bind-html-unsafe="selectContents"></div>



        <div>
            <label for="produto">Produto:</label>
            <select id="produto" name="produto" class="form-control" ng-model="produtos[$index].produto_compra" required>
            <option value="" disabled selected>Selecione </option>
                <option ng-repeat="item in selectContents" value="{{item.produto_id}}">{{item.nome_produto}}</option>
            </select>

            <label for="cor">Cor:</label>
            <select id="cor" name="cor" class="form-control" ng-model="produtos[$index].cor_compra" required>
            <option value="" disabled selected>Selecione uma cor</option>
                <option ng-repeat="item in selectContents" value="{{item.cor_produto}}">{{item.cor_produto}}</option>
            </select>

            <label for="tamanho">Tamanho:</label>
            <select id="tamanho" name="tamanho" class="form-control" ng-model="produtos[$index].tamanho_compra" required>
                <option ng-repeat="item in selectContents" value="{{item.tamanho_produto}}">{{item.tamanho_produto}}</option>
            </select>

            <label for="modelo">Modelo:</label>
            <select id="modelo" name="modelo" class="form-control" ng-model="produtos[$index].modelo_compra" required>
                <option ng-repeat="item in selectContents" value="{{item.modelo_produto}}">{{item.modelo_produto}}</option>
            </select>

            <label for="quantidade">Quantidade:</label>
            <input type="number" id="quantidade" class="form-control" name="quantidade" ng-model="compra[$index].quantidade_compra" required>

            <label for="valor">Valor:</label>
            <input type="text" id="valor" name="valor"class="form-control" ng-model="compra[$index].valor_unitario" required>
        </div>


    </form>
</div>


<script>



</script>