<?php

include '../../api/private/connect.php';


// Verifique se a propriedade 'fornecedor_id' está presente no array
if (isset($_GET['fornecedor_id'])) {
    // Atribua o valor a $fornecedor_id
    $fornecedor_id = $_GET['fornecedor_id'];

    // Restante do seu código aqui...
    $sql = "SELECT * FROM `produtos` WHERE fornecedor_produto_fk = '" . $fornecedor_id . "'";
    $result = $mysqli->query($sql);
    $produtos = $result->fetch_all(MYSQLI_ASSOC);

    echo json_encode($produtos);
    // Agora $fornecedor_id contém o valor desejado
} else {
    // Trate o caso em que 'fornecedor_id' não está presente
    echo "Erro: fornecedor_id não está presente nos dados da solicitação.";
}

?>


