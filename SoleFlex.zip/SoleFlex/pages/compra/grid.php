<?php
include '../../api/private/connect.php';

$produtosQuery = $mysqli->query("SELECT * FROM `produtos` ORDER BY `nome_produto` ASC");
$produtos = $produtosQuery->fetch_all(PDO::FETCH_ASSOC);
?>

<div class="row">
    <div class="col-md-6">
        <h3 class="h3 mb-4 text-gray-800">Lista de Produtos</h3>
    </div>
    
    <div class="col-md-6 text-right">
        <button class="btn btn-info" ng-click="generatePDF()">Relatório</button>
        <button class="btn btn-success" ng-click="send('add')">Cadastrar Novo</button>
    </div>
</div>
<div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <select class="form-control" ng-model="filtroTipo" ng-change="filter(filtroTipo)">
                    <option value="sem-filtro">Sem Filtro</option>
                    <option value='1'>Ativo</option>
                    <option value='0'>Desativado</option>
                </select>
    
            </div>
        </div>
</div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                         
                            <th>VALOR</th>

                            <th>AÇÕES</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr ng-repeat="x in grid">
                            <td>{{x.produto_venda_fk}}</td>
                           
                            <td>{{formatarPreco(x.preco_produto)}}</td>
                            <td>
                                <button class="btn btn-primary btn-sm" ng-click="send($index, x)">Editar</button>
                                <button class="btn btn-danger btn-sm" ng-click="del($index, x)">Deletar</button>
                                <button class="btn btn-info btn-sm" ng-click="toggleDetails(x)">Detalhes</button>

                            </td>

                        </tr>