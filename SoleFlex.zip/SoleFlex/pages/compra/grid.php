<?php
include '../../api/private/connect.php';

$compraQuery = $mysqli->query("SELECT * FROM `compra` INNER JOIN produtos ON compra.produto_compra_fk = produtos.produto_id
INNER JOIN fornecedores ON compra.fornecedor_compra_fk = fornecedores.id");

?>

<div class="row">
    <div class="col-md-6">
        <h3 class="h3 mb-4 text-gray-800">Pedidos de Compra</h3>
    </div>
    
    <div class="col-md-6 text-right">
        <button class="btn btn-success" ng-click="send('add')">Nova Compra</button>
    </div>
</div>


<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>PEDIDO</th>
                        <th>FORNECEDOR</th>
                        <th>PRODUTO</th>
                        <th>COR</th>
                        <th>TAMANHO</th>
                        <th>MARCA</th>
                        <th>MODELO</th>
                        <th>VALOR</th>
                        <th>VALOR TOTAL</th>
                        <th>QUANT</th>
                        <th>DATA</th>
                        <th>STATUS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $compraQuery->fetch_assoc()) { ?>
                        <tr>
                            <td class="text-right"><?php echo $row['compra_id']; ?></td>
                            <td><?php echo $row['nome_fornecedor']; ?></td>
                            <td><?php echo $row['nome_produto']; ?></td>
                            <td><?php echo $row['cor_produto']; ?></td>
                            <td class="text-right"><?php echo $row['tamanho_produto']; ?></td>
                            <td><?php echo $row['marca_produto']; ?></td>
                            <td><?php echo $row['modelo_produto']; ?></td>
                            <td class="text-right">R$<?php echo number_format($row['valor_unitario'], 2, ',', '.'); ?></td>
                            <td class="text-right">R$<?php echo number_format($row['valor_total_compra'], 2, ',', '.'); ?></td>
                            <td class="text-right"><?php echo $row['quantidade_compra']; ?></td>
                            <td class="text-center"><?php echo date('d/m/Y', strtotime($row['data_compra'])); ?></td>
                            <td><?php echo $row['status_compra']; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
