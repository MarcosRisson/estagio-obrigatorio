<div class="container-fluid">
    <form action="" method="post" class="my-1">
    <div class="msg"></div>
        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="documento_cliente">Documento (CPF):</label>
                    <div class="input-group">
                        <input class="form-control" type="text" id="documento_cliente" ng-model="item.documento" required>
                        </button>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="nome_completo">Nome:</label>
                    <input class="form-control" type="text" id="nome_completo" ng-model="item.nome_completo" required>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="email_cliente">Email:</label>
                    <input class="form-control" type="text" id="email_cliente" ng-model="item.email" required>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="password">Senha:</label>
                    <input class="form-control" type="password" id="password" ng-model="item.password" required>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="data_nascimento">Data Nascimento:</label>
                    <input class="form-control" type="text" id="data_nascimento" ng-model="item.data_nascimento" placeholder="DD/MM/YYYY" required>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="genero">Gênero:</label>
                    <select id="genero" name="genero" class="form-select" ng-model="item.genero" required>
                        <option value="M">Masculino</option>
                        <option value="F">Feminino</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="telefone_cliente">Telefone:</label>
                    <input class="form-control" type="text" id="telefone_cliente" ng-model="item.telefone" required>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="cep_cliente">CEP:</label>
                    <div class="input-group">
                        <input class="form-control" type="text" id="cep_cliente" ng-model="item.cep" required>
                        <span class="input-group-btn">
                            <button type="button" class="btn btn-primary" ng-click="getCep()">
                                <span class="ng-confirm-btn-text">Fazer Requisição</span>
                            </button>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-12">
                <div class="form-group">
                    <label for="endereco_cliente">Endereço:</label>
                    <input class="form-control" type="text" id="endereco_cliente" ng-model="item.endereco" required>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="bairro_cliente">Bairro:</label>
                    <input class="form-control" type="text" id="bairro_cliente" ng-model="item.bairro" required>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="cidade_cliente">Cidade:</label>
                    <input class="form-control" type="text" id="cidade_cliente" ng-model="item.cidade" required>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="uf_cliente">UF:</label>
                    <input class="form-control" type="text" id="uf_cliente" ng-model="item.uf" required>
                </div>
            </div>
        </div>

        <div class="form-row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="status_cliente">Status:</label>
                    <select id="status_cliente" name="status_cliente" class="form-control" ng-model="item.status_cliente" required>
                        <option value="Ativo">Ativo</option>
                        <option value="Desativado">Desativado</option>
                    </select>
                </div>
            </div>
        </div>

    </form>
</div>