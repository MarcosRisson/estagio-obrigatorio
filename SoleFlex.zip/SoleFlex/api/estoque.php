<?php
include 'private/connect.php';
include 'private/auth.php';
include 'private/validate.php';

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['list'])) {

    $result = $mysqli->query('SELECT * FROM estoque');
    $rows = array();
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }

    echo json_encode($rows);
}


if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $mysqli->query("SELECT * FROM estoque WHERE id = $id");
    $rows = $result->fetch_assoc();
    echo json_encode($rows);
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_GET['id'])) {

    $valid = isValid(['quantidade_estoque']);

    if ($valid) {
        echo $valid;
    } else {

        $quantidade_estoque = $_POST['quantidade_estoque'];

      

        $mysqli->query("INSERT INTO `estoque` 
            (`quantidade_estoque`) VALUES 
            ('${quantidade_estoque}');
        ");

        $result = array(
            'msg' => 'Cadastro realizado com sucesso',
            'status' => 200
        );
        echo json_encode($result);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['id'])) {

    $valid = isValid(['quantidade_estoque']);

    if ($valid) {
        echo $valid;
    } else {

        $id = $_GET['id'];
        $quantidade_estoque = $_POST['quantidade_estoque'];
    
      

        $mysqli->query("UPDATE `estoque` SET
            `quantidade_estoque`='${quantidade_estoque}', 
          
            WHERE `id`='${id}'
        ");

        $result = array(
            'msg' => 'Atualizado realizado com sucesso',
            'status' => 200
        );
        echo json_encode($result);
    }
}



//deletar registro no dados no database
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del'])) {

    $id = $_GET['del'];
    $mysqli->query("DELETE FROM estoque WHERE `id`='${id}'");

    $result = array(
        'msg' => 'Deletado com sucesso',
        'status' => 200
    );
    echo json_encode($result);
}
?>