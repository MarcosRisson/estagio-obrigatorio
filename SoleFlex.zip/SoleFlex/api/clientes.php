<?php
include 'private/connect.php';
include 'private/auth.php';
include 'private/validate.php';

// listar os usuários cadastrados
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['list'])) {

    $result = $mysqli->query('SELECT * FROM clientes');
    $rows = array();
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }

    echo json_encode($rows);
}

// listar um único item
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $mysqli->query("SELECT * FROM clientes WHERE id = $id");
    $rows = $result->fetch_assoc();
    echo json_encode($rows);
}

// inserir dados no database
if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_GET['id'])) {
    $valid = isValid(['nome_completo', 'email', 'password', 'documento', 'genero', 'data_nascimento', 'telefone', 'cep', 'endereco', 'cidade', 'bairro', 'uf', 'status_cliente']);

    if ($valid) {
        $result = array('msg' => $valid, 'status' => 400);
        echo json_encode($result);
    } else {
        $nome_completo = $_POST['nome_completo'];
        $email = $_POST['email'];
        $password = md5($_POST['password']);
        $documento = $_POST['documento'];
        $data_nascimento = isset($_POST['data_nascimento']) ? formatarDataParaMySQL($_POST['data_nascimento']) : null;
        $telefone = $_POST['telefone'];
        $genero = $_POST['genero'];
        $cep = $_POST['cep'];
        $endereco = $_POST['endereco'];
        $cidade = $_POST['cidade'];
        $bairro = $_POST['bairro'];
        $uf = $_POST['uf'];
        $status_cliente = $_POST['status_cliente'];

        $stmt = $mysqli->prepare("INSERT INTO `clientes` 
    (`nome_completo`, `email`, `password`, `documento`, `data_nascimento`, `telefone`, `genero`, `cep`, `endereco`, `cidade`, `bairro`, `uf`, `status_cliente`) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->bind_param("ssssssssssssi", $nome_completo, $email, $password, $documento, $data_nascimento, $telefone, $genero, $cep, $endereco, $cidade, $bairro, $uf, $status_cliente);

        $stmt->execute();

        $result = array('msg' => 'Cadastro realizado com sucesso', 'status' => 200);
        echo json_encode($result);
    }
}

function formatarDataParaMySQL($data)
{
    $dataFormatada = DateTime::createFromFormat('d/m/Y', $data);
    return $dataFormatada ? $dataFormatada->format('Y-m-d') : null;
}


// atualizar dados no database
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['id'])) {
    $valid = isValid(['nome_completo', 'email', 'password', 'documento', 'genero', 'data_nascimento', 'telefone', 'cep', 'endereco', 'cidade', 'bairro', 'uf', 'status_cliente']);

    if ($valid) {
        $result = array('msg' => $valid, 'status' => 400);
        echo json_encode($result);
    } else {
        $id = $_GET['id'];
        $nome_completo = $_POST['nome_completo'];
        $email = $_POST['email'];
        $password = md5($_POST['password']);
        $documento = $_POST['documento'];
        $data_nascimento = isset($_POST['data_nascimento']) ? formatarDataParaMySQL($_POST['data_nascimento']) : null;
        $telefone = $_POST['telefone'];
        $genero = $_POST['genero'];
        $cep = $_POST['cep'];
        $endereco = $_POST['endereco'];
        $cidade = $_POST['cidade'];
        $bairro = $_POST['bairro'];
        $uf = $_POST['uf'];
        $status_cliente = $_POST['status_cliente'];

        $stmt = $mysqli->prepare("UPDATE `clientes` SET
            `nome_completo`=?, 
            `email`=?, 
            `password`=?, 
            `documento`=?, 
            `data_nascimento`=?, 
            `telefone`=?, 
            `genero`=?, 
            `cep`=?, 
            `endereco`=?, 
            `cidade`=?, 
            `bairro`=?, 
            `uf`=?, 
            `status_cliente`=?
            WHERE `id`=?");

        $stmt->bind_param("ssssssssssssii", $nome_completo, $email, $password, $documento, $data_nascimento, $telefone, $genero, $cep, $endereco, $cidade, $bairro, $uf, $status_cliente, $id);

        $stmt->execute();

        $result = array('msg' => 'Atualização realizada com sucesso', 'status' => 200);
        echo json_encode($result);
    }
}





// deletar registro no dados no database
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del'])) {

    $id = $_GET['del'];
    $mysqli->query("DELETE FROM clientes WHERE `id`='${id}'");

    $result = array('msg' => 'Deletado com sucesso', 'status' => 200);
    echo json_encode($result);
}
?>