<?php
include 'private/connect.php';
include 'private/auth.php';
include 'private/validate.php';

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['list'])) {

    $result = $mysqli->query('SELECT * FROM pedido_compra');
    $rows = array();
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }

    echo json_encode($rows);
}


if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $mysqli->query("SELECT * FROM pedido_compra WHERE id = $id");
    $rows = $result->fetch_assoc();
    echo json_encode($rows);
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_GET['id'])) {
    print_r($_POST); 
    $valid = isValid(['produto_fk', 'compra_fk','quantidade_compra', 'valor_unitario' ,'data_pedido','valor_total_pedido','numero_pedido','status_pedido']);

    if ($valid) {
        echo $valid;
    } else {

        $produto_fk = $_POST['produto_fk'];
        $compra_fk = $_POST['compra_fk'];
        $quantidade_compra = ($_POST['quantidade_compra']);
        $valor_unitario = ($_POST['valor_unitario']);
        $data_pedido = $_POST['data_pedido'];
        $valor_total_pedido = ($_POST['valor_total_pedido']);
        $numero_pedido = ($_POST['numero_pedido']);
        $status_pedido = $_POST['status_pedido'];

        $mysqli->query("INSERT INTO `pedido_compra` 
            (`produto_fk`, `compra_fk`,`quantidade_compra`, `valor_unitario`,`data_pedido`,`valor_total_pedido`,`numero_pedido`,`status_pedido`) VALUES 
            ('${produto_fk}', '${compra_fk}', '${quantidade_compra}','${valor_unitario}, '${data_pedido}','${valor_total_pedido}, '${numero_pedido}','${status_pedido}');
        ");

        $result = array(
            'msg' => 'Cadastro realizado com sucesso',
            'status' => 200
        );
        echo json_encode($result);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['id'])) {

    $valid = isValid(['produto_fk', 'compra_fk','quantidade_compra', 'valor_unitario' ,'data_pedido','valor_total_pedido','numero_pedido','status_pedido']);


    if ($valid) {
        echo $valid;
    } else {

        $id = $_GET['id'];
        $produto_fk = $_POST['produto_fk'];
        $compra_fk = $_POST['compra_fk'];
        $quantidade_compra = ($_POST['quantidade_compra']);
        $valor_unitario = ($_POST['valor_unitario']);
        $data_pedido = $_POST['data_pedido'];
        $valor_total_pedido = ($_POST['valor_total_pedido']);
        $numero_pedido = ($_POST['numero_pedido']);
        $status_pedido = $_POST['status_pedido'];


        $mysqli->query("UPDATE `pedido_compra` SET
            `produto_fk`='${produto_fk}', 
            `compra_fk`='${compra_fk}', 
            `quantidade_compra`='${quantidade_compra}', 
            `valor_unitario`='${valor_unitario}', 
            `valor_total_pedido`='${valor_total_pedido}', 
            `numero_pedido`='${numero_pedido}', 
            `status_compra`='${status_compra}'
            WHERE `id`='${id}'
        ");

        $result = array(
            'msg' => 'Atualizado realizado com sucesso',
            'status' => 200
        );
        echo json_encode($result);
    }
}



//deletar registro no dados no database
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del'])) {

    $id = $_GET['del'];
    $mysqli->query("DELETE FROM pedido_compra WHERE `id`='${id}'");

    $result = array(
        'msg' => 'Deletado com sucesso',
        'status' => 200
    );
    echo json_encode($result);
}



?>