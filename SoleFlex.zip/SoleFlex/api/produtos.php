<?php
include 'private/connect.php';
include 'private/auth.php';
include 'private/validate.php';



if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['list'])){

    $result = $mysqli->query('SELECT * FROM produtos');
    $rows = array();
    while($row = $result->fetch_assoc()){
        $rows[] = $row; 
    }

    echo json_encode($rows);
    
}

//listar um unico item
if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])){
   
    $id = $_GET['id'];
    $result = $mysqli->query("SELECT * FROM produtos WHERE id = $id");
    $rows = $result->fetch_assoc();
    echo json_encode($rows);
}


//inserir dados no database
if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_GET['id'])) {

    $valid = isValid(['fornecedor_produto_fk','estoque_fk', 'nome_produto', 'cor_produto', 'tamanho_produto', 'marca_produto', 'modelo_produto', 'preco_produto', 'status_produto']);

    if ($valid) {
        echo $valid;
    } else {

        $fornecedor_produto_fk = $_POST['fornecedor_produto_fk'];
        $estoque_fk = $_POST['estoque_fk'];
        $nome_produto = $_POST['nome_produto'];
        $cor_produto = $_POST['cor_produto'];
        $tamanho_produto = $_POST['tamanho_produto'];
        $marca_produto = $_POST['marca_produto'];
        $modelo_produto = $_POST['modelo_produto'];
        $preco_produto = $_POST['preco_produto'];
        $status_produto = $_POST['status_produto'];
       

        $mysqli->query("INSERT INTO `produtos` 
            (`fornecedor_produto_fk`,`estoque_fk`, `nome_produto`, `cor_produto`, `tamanho_produto`, `marca_produto`, `modelo_produto`, `preco_produto`,  `status_produto`) 
            VALUES 
            ('${fornecedor_produto_fk}','${estoque_fk}', '${nome_produto}', '${cor_produto}', '${tamanho_produto}', '${marca_produto}', '${modelo_produto}', '${preco_produto}',  '${status_produto}');
        ");

        $result = array('msg' => 'Cadastro realizado com sucesso',
            'status' => 200
        );
        echo json_encode($result);
    }
}

//update dados no database
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['id'])) {
   
    $valid = isValid(['fornecedor_produto_fk','estoque_fk', 'nome_produto', 'cor_produto', 'tamanho_produto', 'marca_produto', 'modelo_produto', 'preco_produto', 'status_produto']);


    if ($valid) {
        echo $valid;
    } else {
        $id = $_GET['id'];
        $fornecedor_produto_fk = $_POST['fornecedor_produto_fk'];
        $estoque_fk = $_POST['estoque_fk'];
        $nome_produto = $_POST['nome_produto'];
        $cor_produto = $_POST['cor_produto'];
        $tamanho_produto = $_POST['tamanho_produto'];
        $marca_produto = $_POST['marca_produto'];
        $modelo_produto = $_POST['modelo_produto'];
        $preco_produto = $_POST['preco_produto'];
        $status_produto = $_POST['status_produto'];
   

        $mysqli->query("UPDATE `produtos` SET

            `fornecedor_produto_fk` = '${fornecedor_produto_fk}',
            `estoque_fk` = '${estoque_fk}',
            `nome_produto`='${nome_produto}', 
            `cor_produto`='${cor_produto}', 
            `tamanho_produto`='${tamanho_produto}', 
            `marca_produto`='${marca_produto}', 
            `modelo_produto`='${modelo_produto}', 
            `preco_produto`='${preco_produto}', 
            `status_produto`='${status_produto}'
            WHERE `id`='${id}'
        ");

        $result = array('msg' => 'Atualizado realizado com sucesso',
            'status' => 200
        );
        echo json_encode($result);
    }
}



//deltar registro no dados no database
if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del'])){

    $id = $_GET['del'];
    $mysqli->query("DELETE FROM produtos WHERE `id`='${id}'");

    $result = array('msg' => 'Deletado com sucesso', 
                    'status' => 200
                );
    echo json_encode($result);

}


?>

