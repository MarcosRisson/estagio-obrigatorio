<?php


include 'private/connect.php';

$query = mysqli_query($mysqli, "SELECT * FROM usuarios WHERE `status` = 'A' ");
$a = [];
while ($row = mysqli_fetch_assoc($query)) {     	
    $a[] = $row;   
}
echo json_encode($a);


?>