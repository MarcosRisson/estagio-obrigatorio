<?php
include 'private/connect.php';

$query = mysqli_query($mysqli, "SELECT * FROM usuarios WHERE `status_usuario` = 'Ativo'");

$a = [];
while ($row = mysqli_fetch_assoc($query)) {     	
    $a[] = $row;   
}
echo json_encode($a);


?>