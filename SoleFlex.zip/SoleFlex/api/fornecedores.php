<?php
include 'private/connect.php';
include 'private/auth.php';
include 'private/validate.php';

// listar os usuários cadastrados
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['list'])) {

    $result = $mysqli->query('SELECT * FROM fornecedores');
    $rows = array();
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }

    echo json_encode($rows);
}

// listar um único item
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $mysqli->query("SELECT * FROM fornecedores WHERE id = $id");
    $rows = $result->fetch_assoc();
    echo json_encode($rows);
}

// inserir dados no database
if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_GET['id'])) {

    $valid = isValid(['nome_fornecedor', 'documento_fornecedor', 'razao_social', 'nome_fantasia', 'cep', 'email_fornecedor', 'telefone', 'endereco', 'bairro', 'cidade', 'uf','status_fornecedor']);

    if ($valid) {
        $result = array('msg' => $valid, 'status' => 400);
        echo json_encode($result);
    } else {

        $nome_fornecedor = $_POST['nome_fornecedor'];
        $documento_fornecedor = $_POST['documento_fornecedor'];
        $razao_social = $_POST['razao_social'];
        $nome_fantasia = $_POST['nome_fantasia'];
        $cep = $_POST['cep'];
        $email_fornecedor = $_POST['email_fornecedor'];
        $telefone = $_POST['telefone'];
        $endereco = $_POST['endereco'];
        $bairro = $_POST['bairro'];
        $cidade = $_POST['cidade'];
        $uf = $_POST['uf'];
        $status_fornecedor = $_POST['status_fornecedor'];


        $mysqli->query("INSERT INTO `fornecedores` 
            (`nome_fornecedor`, `documento_fornecedor`, `razao_social`, `nome_fantasia`, `cep`, `email_fornecedor`, `telefone`, `endereco`, `bairro`,`cidade`, `uf`, `status_fornecedor`) 
            VALUES 
            ('${nome_fornecedor}', '${documento_fornecedor}', '${razao_social}', '${nome_fantasia}', '${cep}', '${email_fornecedor}', '${telefone}', '${endereco}', '${bairro}','${cidade}','${uf}','${status_fornecedor}');
        ");

        $result = array('msg' => 'Cadastro realizado com sucesso', 'status' => 200);
        echo json_encode($result);
    }
}

// atualizar dados no database
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['id'])) {

    $valid = isValid(['nome_fornecedor', 'documento_fornecedor', 'razao_social', 'nome_fantasia', 'cep', 'email_fornecedor', 'telefone', 'endereco', 'bairro', 'cidade', 'uf','status_fornecedor']);
    if ($valid) {
        $result = array('msg' => $valid, 'status' => 400);
        echo json_encode($result);
    } else {

        $id = $_GET['id'];
        $nome_fornecedor = $_POST['nome_fornecedor'];
        $documento_fornecedor = $_POST['documento_fornecedor'];
        $razao_social = $_POST['razao_social'];
        $nome_fantasia = $_POST['nome_fantasia'];
        $cep = $_POST['cep'];
        $email_fornecedor = $_POST['email_fornecedor'];
        $telefone = $_POST['telefone'];
        $endereco = $_POST['endereco'];
        $bairro = $_POST['bairro'];
        $cidade = $_POST['cidade'];
        $uf = $_POST['uf'];
        $status_fornecedor = $_POST['status_fornecedor'];
       

        $mysqli->query("UPDATE `fornecedores` SET
            `nome_fornecedor`='${nome_fornecedor}', 
            `documento_fornecedor`='${documento_fornecedor}', 
            `razao_social`='${razao_social}', 
            `nome_fantasia`='${nome_fantasia}', 
            `cep`='${cep}', 
            `email_fornecedor`='${email_fornecedor}', 
            `telefone`='${telefone}', 
            `endereco`='${endereco}', 
            `bairro`='${bairro}', 
            `cidade`='${cidade}', 
            `uf`='${uf}', 
            `status_fornecedor`='${status_fornecedor}' 
            WHERE `id`='${id}'
        ");

        $result = array('msg' => 'Atualizado realizado com sucesso', 'status' => 200);
        echo json_encode($result);
    }
}

// deletar registro no dados no database
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del'])) {

    $id = $_GET['del'];
    $mysqli->query("DELETE FROM fornecedores WHERE `id`='${id}'");

    $result = array('msg' => 'Deletado com sucesso', 'status' => 200);
    echo json_encode($result);
}
?>
