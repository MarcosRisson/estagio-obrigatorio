<?php
include 'private/connect.php';
include 'private/auth.php';
include 'private/validate.php';

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['list'])) {

    $result = $mysqli->query('SELECT * FROM compra');
    $rows = array();
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }

    echo json_encode($rows);
}


if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $mysqli->query("SELECT * FROM compra WHERE id = $id");
    $rows = $result->fetch_assoc();
    echo json_encode($rows);
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_GET['id'])) {
    print_r($_POST); 
    $valid = isValid(['usuario_fk', 'valor_total_compra','data_compra', 'status_compra']);

    if ($valid) {
        echo $valid;
    } else {

        $usuario_fk = $_POST['usuario_fk'];
        $valor_total_compra = $_POST['valor_total_compra'];
        $data_compra = ($_POST['data_compra']);
        $status_compra = ($_POST['status_compra']);

        $mysqli->query("INSERT INTO `compra` 
            (`usuario_fk`, `valor_total_compra`,`data_compra`, `status_compra`) VALUES 
            ('${usuario_fk}', '${valor_total_compra}', '${data_compra}','${status_compra}');
        ");

        $result = array(
            'msg' => 'Cadastro realizado com sucesso',
            'status' => 200
        );
        echo json_encode($result);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['id'])) {

    $valid = isValid(['usuario_fk', 'valor_total_compra','data_compra', 'status_compra']);

    if ($valid) {
        echo $valid;
    } else {

        $id = $_GET['id'];
        $usuario_fk = $_POST['usuario_fk'];
        $valor_total_compra = $_POST['valor_total_compra'];
        $data_compra = ($_POST['data_compra']);
        $status_compra = ($_POST['status_compra']);


        $mysqli->query("UPDATE `compra` SET
            `usuario_fk`='${usuario_fk}', 
            `valor_total_compra`='${valor_total_compra}', 
            `data_compra`='${data_compra}', 
            `status_compra`='${status_compra}',
            WHERE `id`='${id}'
        ");

        $result = array(
            'msg' => 'Atualizado realizado com sucesso',
            'status' => 200
        );
        echo json_encode($result);
    }
}



//deletar registro no dados no database
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del'])) {

    $id = $_GET['del'];
    $mysqli->query("DELETE FROM compra WHERE `id`='${id}'");

    $result = array(
        'msg' => 'Deletado com sucesso',
        'status' => 200
    );
    echo json_encode($result);
}



?>