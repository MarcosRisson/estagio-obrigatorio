<?php
include 'private/connect.php';
include 'private/auth.php';
include 'private/validate.php';



if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['list'])){

    $result = $mysqli->query('SELECT * FROM compra');
    $rows = array();
    while($row = $result->fetch_assoc()){
        $rows[] = $row; 
    }

    echo json_encode($rows);
    
}

//listar um unico item
if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['compra_id'])){
    $compra_id = $_GET['compra_id'];
    $result = $mysqli->query("SELECT * FROM compra WHERE compra_id = $compra_id");
    $rows = $result->fetch_assoc();
    echo json_encode($rows);
}


//inserir dados no database
if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_GET['compra_id'])) {

    $valid = isValid(['produto', 'fornecedor_produto_fk', 'quantidade',  'valor']);

    if ($valid) {
        echo $valid;
    } else {

        $produto_compra_fk = $_POST['produto'];
        $fornecedor_compra_fk = $_POST['fornecedor_produto_fk'];
        $quantidade_compra = $_POST['quantidade'];
        $valor_unitario = $_POST['valor'];
        $valor_total_compra = $quantidade_compra * $valor_unitario;
        $data_compra = date('Y/m/d');
        $status_compra = 'Aceito';
    
       

        $mysqli->query("INSERT INTO `compra` 
            (`produto_compra_fk`, `fornecedor_compra_fk`, `quantidade_compra`, `valor_total_compra`, `valor_unitario`, `data_compra`, `status_compra`) 
            VALUES 
            ('${produto_compra_fk}', '${fornecedor_compra_fk}', '${quantidade_compra}', '${valor_total_compra}', '${valor_unitario}', '${data_compra}', '${status_compra}');
        ");


$mysqli->query("UPDATE `estoque` SET `quantidade_estoque` = quantidade_estoque + '$quantidade_compra' WHERE produto_estoque_fk = '$produto_compra_fk'");



        $result = array('msg' => 'Compra realizado com sucesso',
            'status' => 200
        );
        echo json_encode($result);
    }
}

//update dados no database
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['compra_id'])) {

    $valid = isValid(['produto_compra_fk', 'fornecedor_compra_fk', 'quantidade_compra', 'valor_total_compra', 'valor_unitario', 'data_compra', 'status_compra']);

    if ($valid) {
        echo $valid;
    } else {
        $compra_id= $_GET['compra_id'];
        $produto_compra_fk = $_POST['produto_compra_fk'];
        $fornecedor_compra_fk = $_POST['fornecedor_compra_fk'];
        $quantidade_compra = $_POST['quantidade_compra'];
        $valor_total_compra = $_POST['valor_total_compra'];
        $valor_unitario = $_POST['valor_unitario'];
        $data_compra = $_POST['data_compra'];
        $status_compra = $_POST['status_compra'];
 
   

        $mysqli->query("UPDATE `compra` SET

            `produto_compra_fk` = '${produto_compra_fk}',
            `fornecedor_compra_fk`='${fornecedor_compra_fk}', 
            `quantidade_compra`='${quantidade_compra}', 
            `valor_total_compra`='${valor_total_compra}', 
            `valor_unitario`='${marca_produto}', 
            `data_compra`='${data_compra}', 
            `status_compra`='${status_compra}'
            WHERE `compra_id`='${compra_id}'
        ");

        $result = array('msg' => 'Atualizado realizado com sucesso',
            'status' => 200
        );
        echo json_encode($result);
    }
}



//deltar registro no dados no database
if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del'])){

    $compra_id = $_GET['del'];
    $mysqli->query("DELETE FROM compra WHERE `compra_id`='${compra_id}'");

    $result = array('msg' => 'Deletado com sucesso', 
                    'status' => 200
                );
    echo json_encode($result);

}



?>