<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" type="image/png" sizes="16x16" href="./src/img/ammeshoesicon.ico">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>AmmeShoes</title>

    <link href="./src/fonts/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="./src/css/admin.min.css" rel="stylesheet">
    <link href="./src/css/app.css" rel="stylesheet">
    <link href="./src/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
    <div id="loading" class="open">
        <img src="./src/img/loading.gif">
    </div>

    <section class="vh-100">
        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col col-xl-5">
                    <div class="card border border-dark-subtle o-hidden border-1 shadow-lg p-3 mb-5 bg-body-tertiary rounded">
                        <div class="d-flex align-items-center">
                            <div class="card-body p-4 p-lg-5 text-black">
                                <form id="login" class="user" method="POST" action="/SoleFlex/api/login.php" onsubmit="return false;">
                                    <div class="d-flex justify-content-center mb-3 pb-3">
                                        <span class="h1 text-center fw-bold mb-3">AmmeShoes</span>
                                    </div>
                                    <div class="form-outline mb-4">
                                        <label class="form-label" for="email" style="margin-left: 0px;">Email</label>
                                        <input type="email" name="email" id="email" class="form-control form-control-lg" placeholder="Digite seu email...">
                                    </div>
                                    <div class="form-outline mb-5">
                                        <label class="form-label" for="password">Senha</label>
                                        <input type="password" id="password" name="password" class="form-control form-control-lg" placeholder="Digite sua senha...">
                                    </div>
                                    <div class="pt-1 mb-4 d-flex justify-content-center">
                                        <button class="btn btn-dark btn-lg d-grid gap-2 col-12 mx-auto" type="submit">Login</button>
                                    </div>
                                    <div class="msg"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="./src/lib/jquery.min.js"></script>
    <script src="./src/lib/bootstrap.min.js"></script>
    <script src="./src/lib/jquery.easing.min.js"></script>
    <script src="./src/js/admin.min.js"></script>

    <script>
        let loading;
        $(document).ready(() => {
            loading = $('#loading').toggleClass('open');
        });

        $("#login").submit(function(e) {
            e.preventDefault();
            loading.toggleClass('open');
            let data = $(this).serializeArray();
            $.post(this.action, data, function(rs) {
                let msg = $('.msg').text('Email ou senha inválida');
                if (rs.status == 200) {
                    msg.text(rs.msg).addClass('alert alert-success');
                    setTimeout(function() {
                        localStorage.setItem('@token', 'true');
                        window.location.href = "./";
                    }, 2000);
                } else {
                    msg.addClass('alert alert-danger');
                    loading.toggleClass('open');
                }
            });
        });
    </script>

</body>

</html>