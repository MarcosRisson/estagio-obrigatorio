
var app = angular.module('myApp', ['ui.router', 'cp.ngConfirm']);


app.controller('ctrlGlobal', function ($scope, $http, $ngConfirm) {
    $scope.logout = function () {
        $ngConfirm({
            title: 'Atenção',
            content: 'Tem certeza que deseja sair do sistema?',
            scope: $scope,
            buttons: {
                not: {
                    text: 'Não',
                    btnClass: 'btn-danger'
                },
                yes: {
                    text: 'Sim',
                    btnClass: 'btn-primary',
                    action: function () {
                        $http.post('./api/login.php?logout')
                            .then(function () {
                                localStorage.removeItem('@token');
                                window.location.href = './';
                            })
                            .catch(function (error) {
                                console.error('Erro ao fazer logout:', error);
                            });
                    }
                }
            }
        });
    };

    // Função para formatar o preço de ponto para vírgula
    $scope.formatarPreco = function (preco) {
        // Substitui o ponto por vírgula
        var precoFormatado = preco.toString().replace(/\./g, ",");
        return "R$ " + precoFormatado;
    };

    // Função para formatar o documento (CPF)
    $scope.formatarDocumento = function (documento) {
        // Verifica se o documento possui o formato de CPF (11 dígitos)
        if (documento && documento.length === 11) {
            // Formata o CPF com pontos e traço
            return documento.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
        } else {
            // Retorna o documento sem formatação se não estiver no formato esperado
            return documento;
        }
    };
});


app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {

    // Define a rota padrão como '/'
    $urlRouterProvider.otherwise('/');

    // Verifica se há um token no armazenamento local
    let token = localStorage.getItem('@token');
    if (token == null) {
        // Redireciona para a página de login se não houver token
        window.location.href = '/SoleFlex/login.php';
    }

    // Configuração dos estados (rotas) da aplicação
    $stateProvider
        .state('home', {
            url: '/',
            template: '<div class="container-fluid">' +
                '<div class="container">' +
                '<div class="jumbotron">' +
                '<h1 class="display-4 text-center">Bem-vindo ao Sistema SOLE FLEX</h1>' +
                '<p class="lead">Projeto desenvolvido para a entrega do Estágio Supervisionado I.</p>' +
                '<p class="lead">Proposto pela instituição UMFG em colaboração com a empresa AMME SHOES.</p>' +
                '<hr class="my-4">' +
                '</div>' +
                '</div>' +
                '</div>'
        })

        .state('usuario', {
            url: '/usuario',
            templateUrl: './pages/usuarios/grid.php',
            controller: function ($scope, $http, $ngConfirm) {
                // Lista os dados de usuários
                $http.get('./api/usuarios.php?list')
                    .then(function (response) {
                        $scope.grid = response.data;
                    });

                // Função para deletar um usuário
                $scope.del = function (k, i) {
                    $ngConfirm({
                        title: 'Atenção',
                        content: 'Tem certeza que deseja remover este item?',
                        scope: $scope,
                        buttons: {
                            not: {
                                text: 'Não',
                                btnClass: 'btn-danger'
                            },
                            yes: {
                                text: 'Sim',
                                btnClass: 'btn-primary',
                                action: function () {
                                    // Remove o item da lista local
                                    $scope.grid.splice(k, 1);
                                    $scope.$apply();

                                    // Chama a API para deletar o item
                                    $.get('./api/usuarios.php?del=' + i.id)
                                        .then(function () {
                                            $.alert('Registro deletado com sucesso.');
                                        });
                                }
                            }
                        }
                    });
                };

                // Função para adicionar ou editar dados de usuário
                $scope.send = function (k, i) {
                    // Copia os dados do usuário para edição
                    $scope.item = angular.copy(i);

                    $ngConfirm({
                        title: (k == 'add') ? 'Cadastrar Usuario' : 'Atualizar Usuario',
                        contentUrl: './pages/usuarios/form.php',
                        scope: $scope,
                        typeAnimed: true,
                        closeIcon: true,
                        theme: 'light',
                        buttons: {
                            yes: {
                                text: (k == 'add') ? 'Salvar' : 'Editar',
                                btnClass: 'btn-primary',
                                action: function (scope, button) {
                                    let ids = (k == 'add') ? '' : '?id=' + i.id;
                                    let data = $scope.item;

                                    // Envia os dados para a API (POST para adição, PUT para edição)
                                    $.post('./api/usuarios.php' + ids, data, function (rs) {
                                        $('.msg').text(rs.msg).removeClass('alert-danger');

                                        if (rs.status == 200) {
                                            $('.msg').addClass('alert alert-success');

                                            if (k == 'add') {
                                                $scope.grid.push($scope.item);
                                            } else {
                                                $scope.grid[k] = $scope.item;
                                            }

                                            $scope.$apply();
                                            setTimeout(function () {
                                                $('.ng-confirm').remove();
                                            }, 1000);
                                            window.location.reload();
                                        } else {
                                            $('.msg').addClass('alert alert-danger');
                                            return false;
                                        }
                                    }, "json");

                                    return false;
                                }
                            }
                        }
                    });
                };
            }
        })

    // Configuração do estado (rota) 'clientes'
    $stateProvider.state('clientes', {
        url: '/clientes',
        templateUrl: './pages/clientes/grid.php',
        controller: function ($scope, $http, $ngConfirm) {

            // Função para obter dados do CEP através da API ViaCEP
            $scope.getCep = function () {
                $.getJSON("https://viacep.com.br/ws/" + $scope.item.cep + "/json/?callback=?", function (dados) {
                    $scope.item.endereco = dados.logradouro;
                    $scope.item.bairro = dados.bairro;
                    $scope.item.cidade = dados.localidade;
                    $scope.item.uf = dados.uf;
                });
            };








            $scope.generatePDF = function () {
                // Obtém o valor selecionado do filtro
                const filtroSelecionado = $scope.filtroTipo || "Sem Filtro";

                // Clona a tabela para evitar manipulações no original
                const tabelaClonada = document.getElementById('dataTable').cloneNode(true);

                // Remove os botões de imprimir, editar e deletar
                const botoesRemovidos = tabelaClonada.querySelectorAll('.notPrint');
                botoesRemovidos.forEach(function (botao) {
                    botao.parentNode.removeChild(botao);
                });

                // Ajusta o estilo da tabela para garantir que o cabeçalho fique acima do corpo
                const estilo = "<style>" +
                    "body {font-family: Arial, sans-serif;}" + // Especifica a fonte para o corpo do documento
                    "h3 {color: #333;}" + // Cor do título
                    "table {width: 100%; border-collapse: collapse; margin-bottom: 20px;}" +
                    "table, th, td {border: 1px solid #ddd;}" +
                    "th, td {padding: 12px; text-align: left;}" +
                    "th {background-color: #f2f2f2;}" +
                    "tr:hover {background-color: #f5f5f5;}" +
                    "thead {display: table-header-group;}" +  // Garante que o cabeçalho seja tratado como grupo de cabeçalho
                    ".noPrint {display: none;}" +  // Adiciona uma classe para ocultar o botão de imprimir
                    "td, th {border: 1px solid #ddd;}" + // Adiciona bordas para células
                    "tr {border-bottom: 1px solid #ddd;}" + // Adiciona borda inferior para linhas
                    "</style>";

                // Obtém o conteúdo HTML da tabela clonada
                const conteudo = tabelaClonada.outerHTML;

                // Abrir uma nova janela para gerar o PDF
                const win = window.open('', '', 'height=700, width=700');

                win.document.write('<html><img src="./src/img/SoleFlexLogo.png" style=" width: 110px; height: 100px; border-radius: 20px" alt="logo"><head>');
                win.document.write('<title>Relatorio de Fornecedores</title>');
                win.document.write(estilo);
                win.document.write('</head><body>');
                win.document.write('<h3 style="text-align: center;">Cadastro de Fornecedores</h3>');
                win.document.write('<div style="text-align: right; margin-bottom: 10px;">');
                win.document.write('<p>FILTRO: "' + filtroSelecionado + '"</p>'); // Adiciona o valor do filtro no PDF
                win.document.write('<button class="btn btn-info noPrint" onclick="window.print()">Imprimir</button>');
                win.document.write('</div>');
                win.document.write(conteudo);
                win.document.write('</body></html>');
                win.print();
            };

            $scope.showDetailsForm = false;
            $scope.selectedCliente = {};

            $scope.toggleDetails = function (cliente) {
                if ($scope.showDetailsForm && angular.equals($scope.selectedCliente, cliente)) {
                    $scope.showDetailsForm = false;
                } else {
                    $scope.selectedCliente = angular.copy(cliente);
                    $scope.showDetailsForm = true;
                }
            };



            // Listar dados de clientes
            $http.get('./api/clientes.php?list')
                .then(function (response) {
                    $scope.grid = response.data;

                    $scope.filter = function (filtro) {
                        if (filtro === "sem-filtro") {
                            // Recarrega a página se nenhum filtro for aplicado
                            window.location.reload();
                        } else {
                            // Faz uma requisição para obter os dados filtrados pelo status do fornecedor
                            $http.get('./api/clientes.php?list')
                                .then(function (response) {
                                    $scope.grid = response.data.filter(function (cliente) {
                                        return cliente.status_cliente === filtro;
                                    });
                                });
                        }
                    };
                });

            // Função para deletar um item da lista
            $scope.del = function (k, i) {
                $ngConfirm({
                    title: 'Atenção',
                    content: 'Tem certeza que deseja remover este item?',
                    scope: $scope,
                    buttons: {
                        not: {
                            text: 'Não',
                            btnClass: 'btn-danger'
                        },
                        yes: {
                            text: 'Sim',
                            btnClass: 'btn-primary',
                            action: function () {
                                // Remove o item da lista local
                                $scope.grid.splice(k, 1);
                                $scope.$apply();

                                // Chama a API para deletar o item
                                $.get('./api/clientes.php?del=' + i.cliente_id)
                                    .then(function (response) {
                                        $.alert(response.msg);
                                    });
                            }
                        }
                    }
                });
            };

            // Função para adicionar ou editar dados de cliente
            $scope.send = function (k, i) {
                // Copia os dados do cliente para edição
                $scope.item = angular.copy(i);

                $ngConfirm({
                    title: (k == 'add') ? 'Cadastrar Cliente' : 'Atualizar Cliente',
                    contentUrl: './pages/clientes/form.php',
                    scope: $scope,
                    typeAnimed: true,
                    closeIcon: true,
                    useBootstrap: true,
                    columnClass: 'col-md-8 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1',
                    theme: 'light',
                    buttons: {
                        yes: {
                            text: (k == 'add') ? 'Salvar' : 'Editar',
                            btnClass: 'btn-primary',
                            action: function (scope, button) {
                                let ids = (k == 'add') ? '' : '?cliente_id=' + i.cliente_id;
                                let data = $scope.item;

                                // Envia os dados para a API (POST para adição, PUT para edição)
                                $.post('./api/clientes.php' + ids, data, function (rs) {
                                    $('.msg').text(rs.msg).removeClass('alert-danger');

                                    if (rs.status == 200) {
                                        $('.msg').addClass('alert alert-success');

                                        if (k == 'add') {
                                            $scope.grid.push($scope.item);
                                        } else {
                                            $scope.grid[k] = $scope.item;
                                        }

                                        $scope.$apply();
                                        setTimeout(function () {
                                            $('.ng-confirm').remove();
                                        }, 1000);
                                        window.location.reload();
                                    } else {
                                        $('.msg').addClass('alert alert-danger');
                                        $.alert(rs.msg);
                                    }
                                }, "json");

                                return false;
                            }
                        }
                    }
                });
            };
        }
    })


    // Configuração do estado (rota) 'fornecedores'
    $stateProvider.state('fornecedores', {
        url: '/fornecedores',
        templateUrl: './pages/fornecedores/grid.php',
        controller: function ($scope, $http, $ngConfirm) {

            // Função para filtrar dados com base no status do fornecedor
            $scope.filter = function (filtro) {
                if (filtro === "sem-filtro") {
                    // Recarrega a página se nenhum filtro for aplicado
                    window.location.reload();
                } else {
                    // Faz uma requisição para obter os dados filtrados pelo status do fornecedor
                    $http.get('./api/fornecedores.php?list')
                        .then(function (response) {
                            $scope.grid = response.data.filter(function (fornecedor) {
                                return fornecedor.status_fornecedor === filtro;
                            });
                        });
                }
            };

            // Variáveis para controlar a exibição do formulário de detalhes
            $scope.showDetailsForm = false;
            $scope.selectedFornecedor = {};

            // Função para alternar a exibição do formulário de detalhes
            $scope.toggleDetails = function (fornecedor) {
                if ($scope.showDetailsForm && angular.equals($scope.selectedFornecedor, fornecedor)) {
                    $scope.showDetailsForm = false;
                } else {
                    $scope.selectedFornecedor = angular.copy(fornecedor);
                    $scope.showDetailsForm = true;
                }
            };

            // Função para fazer requisição de detalhes usando um serviço externo (ViaCEP)
            $scope.fazerRequisicao = function () {
                // Verifica se o documento_fornecedor está preenchido antes de fazer a requisição
                if ($scope.item.documento_fornecedor) {
                    // Faz uma requisição para obter detalhes do fornecedor com base no CNPJ
                    $.getJSON("https://api-publica.speedio.com.br/buscarcnpj?cnpj=" + $scope.item.documento_fornecedor, function (dados) {
                        $scope.$apply(function () {
                            // Atualiza os campos do fornecedor com os dados obtidos
                            $scope.item.endereco = dados.LOGRADOURO;
                            $scope.item.bairro = dados.BAIRRO;
                            $scope.item.cidade = dados.MUNICIPIO;
                            $scope.item.uf = dados.UF;
                            $scope.item.razao_social = dados['RAZAO SOCIAL'];
                            $scope.item.nome_fantasia = dados['NOME FANTASIA'];
                            $scope.item.cep = dados.CEP;
                            $scope.item.telefone = dados.TELEFONE;
                            $scope.item.email_fornecedor = dados.EMAIL;
                        });
                    });
                }
            };

            // Função para gerar um PDF da tabela de fornecedores
            $scope.generatePDF = function () {
                // Obtém o valor selecionado do filtro
                const filtroSelecionado = $scope.filtroTipo || "Sem Filtro";

                // Clona a tabela para evitar manipulações no original
                const tabelaClonada = document.getElementById('dataTable').cloneNode(true);

                // Remove os botões de imprimir, editar e deletar
                const botoesRemovidos = tabelaClonada.querySelectorAll('.notPrint');
                botoesRemovidos.forEach(function (botao) {
                    botao.parentNode.removeChild(botao);
                });

                // Ajusta o estilo da tabela para garantir que o cabeçalho fique acima do corpo
                const estilo = "<style>" +
                    "body {font-family: Arial, sans-serif;}" + // Especifica a fonte para o corpo do documento
                    "h3 {color: #333;}" + // Cor do título
                    "table {width: 100%; border-collapse: collapse; margin-bottom: 20px;}" +
                    "table, th, td {border: 1px solid #ddd;}" +
                    "th, td {padding: 12px; text-align: left;}" +
                    "th {background-color: #f2f2f2;}" +
                    "tr:hover {background-color: #f5f5f5;}" +
                    "thead {display: table-header-group;}" +  // Garante que o cabeçalho seja tratado como grupo de cabeçalho
                    ".noPrint {display: none;}" +  // Adiciona uma classe para ocultar o botão de imprimir
                    "td, th {border: 1px solid #ddd;}" + // Adiciona bordas para células
                    "tr {border-bottom: 1px solid #ddd;}" + // Adiciona borda inferior para linhas
                    "</style>";

                // Obtém o conteúdo HTML da tabela clonada
                const conteudo = tabelaClonada.outerHTML;

                // Abrir uma nova janela para gerar o PDF
                const win = window.open('', '', 'height=700, width=700');

                win.document.write('<html><img src="./src/img/SoleFlexLogo.png" style=" width: 110px; height: 100px; border-radius: 20px" alt="logo"><head>');
                win.document.write('<title>Relatorio de Fornecedores</title>');
                win.document.write(estilo);
                win.document.write('</head><body>');
                win.document.write('<h3 style="text-align: center;">Cadastro de Fornecedores</h3>');
                win.document.write('<div style="text-align: right; margin-bottom: 10px;">');
                win.document.write('<p>FILTRO: "' + filtroSelecionado + '"</p>'); // Adiciona o valor do filtro no PDF
                win.document.write('<button class="btn btn-info noPrint" onclick="window.print()">Imprimir</button>');
                win.document.write('</div>');
                win.document.write(conteudo);
                win.document.write('</body></html>');
                win.print();
            };

            // Listar dados de fornecedores
            $http.get('./api/fornecedores.php?list')
                .then(function (response) {
                    $scope.grid = response.data;
                });

            // Função para deletar um fornecedor da lista
            $scope.del = function (k, i) {
                $ngConfirm({
                    title: 'Atenção',
                    content: 'Tem certeza que deseja remover este item?',
                    scope: $scope,
                    buttons: {
                        not: {
                            text: 'Não',
                            btnClass: 'btn-danger'
                        },
                        yes: {
                            text: 'Sim',
                            btnClass: 'btn-primary',
                            action: function () {
                                // Remove o fornecedor da lista local
                                $scope.grid.splice(k, 1);
                                $scope.$apply();

                                // Chama a API para deletar o fornecedor
                                $.get('./api/fornecedores.php?del=' + i.id)
                                    .then(function (response) {
                                        $.alert(response.msg);
                                    });
                            }
                        }
                    }
                });
            };

            // Função para adicionar ou editar dados de fornecedor
            $scope.send = function (k, i) {
                // Copia os dados do fornecedor para edição
                $scope.item = angular.copy(i);

                $ngConfirm({
                    title: (k == 'add') ? 'Cadastrar Fornecedor' : 'Atualizar Fornecedor',
                    contentUrl: './pages/fornecedores/form.php',
                    scope: $scope,
                    typeAnimed: true,
                    closeIcon: true,
                    columnClass: 'col-md-8 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1',
                    theme: 'light',
                    buttons: {
                        yes: {
                            text: (k == 'add') ? 'Salvar' : 'Editar',
                            btnClass: 'btn-primary',
                            action: function (scope, button) {
                                let ids = (k == 'add') ? '' : '?id=' + i.id;
                                let data = $scope.item;

                                // Envia os dados para a API (POST para adição, PUT para edição)
                                $.post('./api/fornecedores.php' + ids, data, function (rs) {
                                    $('.msg').text(rs.msg).removeClass('alert-danger');

                                    if (rs.status == 200) {
                                        $('.msg').addClass('alert alert-success');

                                        if (k == 'add') {
                                            $scope.grid.push($scope.item);
                                        } else {
                                            $scope.grid[k] = $scope.item;
                                        }

                                        $scope.$apply();
                                        setTimeout(function () {
                                            $('.ng-confirm').remove();
                                        }, 1000);
                                        window.location.reload();
                                    } else {
                                        $('.msg').addClass('alert alert-danger');
                                        $.alert(rs.msg);
                                        return false;
                                    }
                                }, "json");

                                return false;
                            }
                        }
                    }
                });
            };
        }
    })


        .state('produtos', {
            url: '/produtos',
            templateUrl: './pages/produtos/grid.php',
            controller: function ($scope, $http, $ngConfirm) {

                $scope.filter = function (filtro) {
                    if (filtro === "sem-filtro") {
                        window.location.reload();
                    } else {
                        $http.get('./api/produtos.php?list')
                            .then(function (response) {
                                $scope.grid = response.data.filter(function (produto) {
                                    return produto.status_produto === filtro;
                                })
                            });
                    }
                }


                // Função para gerar um PDF da tabela de fornecedores
                $scope.generatePDF = function () {
                    // Obtém o valor selecionado do filtro
                    const filtroSelecionado = $scope.filtroTipo || "Sem Filtro";

                    // Clona a tabela para evitar manipulações no original
                    const tabelaClonada = document.getElementById('dataTable').cloneNode(true);

                    // Remove os botões de imprimir, editar e deletar
                    const botoesRemovidos = tabelaClonada.querySelectorAll('.notPrint');
                    botoesRemovidos.forEach(function (botao) {
                        botao.parentNode.removeChild(botao);
                    });

                    // Ajusta o estilo da tabela para garantir que o cabeçalho fique acima do corpo
                    const estilo = "<style>" +
                        "body {font-family: Arial, sans-serif;}" + // Especifica a fonte para o corpo do documento
                        "h3 {color: #333;}" + // Cor do título
                        "table {width: 100%; border-collapse: collapse; margin-bottom: 20px;}" +
                        "table, th, td {border: 1px solid #ddd;}" +
                        "th, td {padding: 12px; text-align: left;}" +
                        "th {background-color: #f2f2f2;}" +
                        "tr:hover {background-color: #f5f5f5;}" +
                        "thead {display: table-header-group;}" +  // Garante que o cabeçalho seja tratado como grupo de cabeçalho
                        ".noPrint {display: none;}" +  // Adiciona uma classe para ocultar o botão de imprimir
                        "td, th {border: 1px solid #ddd;}" + // Adiciona bordas para células
                        "tr {border-bottom: 1px solid #ddd;}" + // Adiciona borda inferior para linhas
                        "</style>";

                    // Obtém o conteúdo HTML da tabela clonada
                    const conteudo = tabelaClonada.outerHTML;

                    // Abrir uma nova janela para gerar o PDF
                    const win = window.open('', '', 'height=700, width=700');

                    win.document.write('<html><img src="./src/img/SoleFlexLogo.png" style=" width: 110px; height: 100px; border-radius: 20px" alt="logo"><head>');
                    win.document.write('<title>Relatorio de Fornecedores</title>');
                    win.document.write(estilo);
                    win.document.write('</head><body>');
                    win.document.write('<h3 style="text-align: center;">Cadastro de Fornecedores</h3>');
                    win.document.write('<div style="text-align: right; margin-bottom: 10px;">');
                    win.document.write('<p>FILTRO: "' + filtroSelecionado + '"</p>'); // Adiciona o valor do filtro no PDF
                    win.document.write('<button class="btn btn-info noPrint" onclick="window.print()">Imprimir</button>');
                    win.document.write('</div>');
                    win.document.write(conteudo);
                    win.document.write('</body></html>');
                    win.print();
                };






                // listar dados
                $http.get('./api/produtos.php?list')
                    .then(function (response) {
                        $scope.grid = response.data;
                    });

                $scope.showDetailsForm = false;
                $scope.selectedProduct = {};

                $scope.toggleDetails = function (produto) {
                    if ($scope.showDetailsForm && angular.equals($scope.selectedProduct, produto)) {
                        $scope.showDetailsForm = false;
                    } else {
                        $scope.selectedProduct = angular.copy(produto);
                        $scope.showDetailsForm = true;
                    }
                };

                // deletar item
                $scope.del = function (k, i) {

                    $ngConfirm({
                        title: 'Atenção',
                        content: 'Tem certeza que deseja remover este item?',
                        scope: $scope,
                        buttons: {
                            not: {
                                text: 'Não',
                                btnClass: 'btn-danger'
                            },
                            yes: {
                                text: 'Sim',
                                btnClass: 'btn-primary',
                                action: function () {

                                    $scope.grid.splice(k, 1);
                                    $scope.$apply();

                                    $.get('./api/produtos.php?del=' + i.produto_id)
                                        .then(function (response) {
                                            $.alert(response.msg);
                                        });
                                }
                            }
                        }
                    });
                };

                // função para adicionar e editar dados
                $scope.send = function (k, i) {

                    $scope.item = angular.copy(i);

                    $ngConfirm({
                        title: (k == 'add') ? 'Cadastrar Produto' : 'Atualizar Produto',
                        contentUrl: './pages/produtos/form.php',
                        scope: $scope,
                        typeAnimed: true,
                        closeIcon: true,
                        columnClass: 'col-md-8 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1',
                        theme: 'light',
                        buttons: {
                            yes: {
                                text: (k == 'add') ? 'Salvar' : 'Editar',
                                btnClass: 'btn-primary',
                                action: function (scope, button) {

                                    let ids = (k == 'add') ? '' : '?produto_id=' + i.produto_id;
                                    let data = $scope.item;
                                    $.post('./api/produtos.php' + ids, data, function (rs) {

                                        $('.msg').text(rs.msg).removeClass('alert-danger');

                                        if (rs.status == 200) {
                                            $('.msg').addClass('alert alert-success');

                                            if (k == 'add') {
                                                console.log($scope.item);
                                                $scope.grid.push($scope.item);
                                            } else {
                                                $scope.grid[k] = $scope.item;
                                            }

                                            $scope.$apply();
                                            setTimeout(function () {
                                                $('.ng-confirm').remove();
                                                window.location.reload();
                                            }, 1000);

                                        } else {
                                            $('.msg').addClass('alert alert-danger');
                                            return false;
                                        }

                                    }, "json");

                                    return false;
                                }
                            }
                        }
                    });
                };
            }
        })


        .state('compra', {
            url: '/compra',
            templateUrl: './pages/compra/grid.php',
            controller: function ($scope, $rootScope, $http, $ngConfirm) {

                $scope.loadProdutos = function () {
                    var selectedValue = $scope.item.fornecedor_produto_fk;

                    $http.get('/SoleFlex/pages/compra/selectProdutosCompra.php?fornecedor_id=' + selectedValue)
                        .then(function (response) {
                            $scope.selectContents = (response.data);
                            console.log($scope.selectContents);
                        })
                        .catch(function (error) {
                            console.error('Erro na solicitação AJAX:', error);
                        });
                };

                $scope.$watch('item.fornecedor_produto_fk', function (newValue, oldValue) {
                    if (newValue !== oldValue) {
                        $scope.loadProdutos();
                    }
                });

                $scope.filter = function (filtro) {
                    if (filtro === "sem-filtro") {
                        window.location.reload();
                    } else {
                        $http.get('./api/compra.php?list')
                            .then(function (response) {
                                $scope.grid = response.data.filter(function (produto) {
                                    return produto.status_produto === filtro;
                                })
                            });
                    }
                }

                // listar dados
                $http.get('./api/compra.php?list')
                    .then(function (response) {
                        $scope.grid = response.data;
                    });

                $scope.showDetailsForm = false;
                $scope.selectedProduct = {};

                $scope.toggleDetails = function (produto) {
                    if ($scope.showDetailsForm && angular.equals($scope.selectedProduct, produto)) {
                        $scope.showDetailsForm = false;
                    } else {
                        $scope.selectedProduct = angular.copy(produto);
                        $scope.showDetailsForm = true;
                    }
                };

                // deletar item
                $scope.del = function (k, i) {

                    $ngConfirm({
                        title: 'Atenção',
                        content: 'Tem certeza que deseja remover este item?',
                        scope: $scope,

                        buttons: {
                            not: {
                                text: 'Não',
                                btnClass: 'btn-danger'
                            },
                            yes: {
                                text: 'Sim',
                                btnClass: 'btn-primary',
                                action: function () {

                                    $scope.grid.splice(k, 1);
                                    $scope.$apply();

                                    $.get('./api/compra.php?del=' + i.compra_id)
                                        .then(function (response) {
                                            $.alert(response.msg);
                                        });
                                }
                            }
                        }
                    });
                };





                // função para adicionar e editar dados
                $scope.send = function (k, i) {
                    $scope.item = angular.copy(i);

                    $ngConfirm({
                        title: (k == 'add') ? 'Comprar Produto' : 'Atualizar Compra',
                        contentUrl: './pages/compra/form.php',
                        scope: $scope,
                        typeAnimed: true,
                        closeIcon: true,
                        columnClass: 'col-lx-8',
                        buttons: {
                            yes: {
                                text: (k == 'add') ? 'Salvar' : 'Editar',
                                btnClass: 'btn-primary',
                                action: function (scope, button) {
                                    let ids = (k == 'add') ? '' : '?compra_id=' + i.compra_id;

                                    // Use jQuery para serializar os dados do formulário
                                    let serializedData = $('form').serialize();

                                    $http.post('./api/compra.php' + ids, serializedData, {
                                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                                    }).then(function (response) {
                                        console.log(response.data);

                                        $('.msg').text(response.data.msg).removeClass('alert-danger');

                                        if (response.data.status == 200) {
                                            $('.msg').addClass('alert alert-success');

                                            if (k == 'add') {
                                                console.log($scope.item);
                                                $scope.grid.push($scope.item);
                                            } else {
                                                $scope.grid[k] = $scope.item;
                                            }

                                            $scope.$apply();
                                            setTimeout(function () {
                                                $('.ng-confirm').remove();
                                                window.location.reload();
                                            }, 1000);
                                        } else {
                                            $('.msg').addClass('alert alert-danger');
                                        }
                                    }, "json");

                                    return false;
                                }
                            }
                        }
                    });
                };
            }
        })


        .state('estoque', {
            url: '/estoque',
            templateUrl: './pages/estoque/grid.php',
            controller: function ($scope, $http, $ngConfirm) {

                $scope.filter = function (filtro) {
                    if (filtro === "sem-filtro") {
                        window.location.reload();
                    } else {
                        $http.get('./api/estoque.php?list')
                            .then(function (response) {
                                $scope.grid = response.data.filter(function (produto) {
                                    return produto.status_produto === filtro;
                                })
                            });
                    }
                }

                // listar dados
                $http.get('./api/estoque.php?list')
                    .then(function (response) {
                        $scope.grid = response.data;
                    });



                // deletar item
                $scope.del = function (k, i) {

                    $ngConfirm({
                        title: 'Atenção',
                        content: 'Tem certeza que deseja remover este item?',
                        scope: $scope,
                        buttons: {
                            not: {
                                text: 'Não',
                                btnClass: 'btn-danger'
                            },
                            yes: {
                                text: 'Sim',
                                btnClass: 'btn-primary',
                                action: function () {

                                    $scope.grid.splice(k, 1);
                                    $scope.$apply();

                                    $.get('./api/estoque.php?del=' + i.produto_id)
                                        .then(function (response) {
                                            $.alert(response.msg);
                                        });
                                }
                            }
                        }
                    });
                };

                // função para adicionar e editar dados
                $scope.send = function (k, i) {

                    $scope.item = angular.copy(i);

                    $ngConfirm({
                        title: (k == 'add') ? 'Cadastrar Produto' : 'Atualizar Produto',
                        contentUrl: './pages/estoque/form.php',
                        scope: $scope,
                        typeAnimed: true,
                        closeIcon: true,
                        columnClass: 'col-md-8 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1',
                        theme: 'light',
                        buttons: {
                            yes: {
                                text: (k == 'add') ? 'Salvar' : 'Editar',
                                btnClass: 'btn-primary',
                                action: function (scope, button) {

                                    let ids = (k == 'add') ? '' : '?produto_id=' + i.produto_id;
                                    let data = $scope.item;
                                    $.post('./api/estoque.php' + ids, data, function (rs) {

                                        $('.msg').text(rs.msg).removeClass('alert-danger');

                                        if (rs.status == 200) {
                                            $('.msg').addClass('alert alert-success');

                                            if (k == 'add') {
                                                console.log($scope.item);
                                                $scope.grid.push($scope.item);
                                            } else {
                                                $scope.grid[k] = $scope.item;
                                            }

                                            $scope.$apply();
                                            setTimeout(function () {
                                                $('.ng-confirm').remove();
                                                window.location.reload();
                                            }, 1000);

                                        } else {
                                            $('.msg').addClass('alert alert-danger');
                                            return false;
                                        }

                                    }, "json");

                                    return false;
                                }
                            }
                        }
                    });
                };
            }
        })

}]);

