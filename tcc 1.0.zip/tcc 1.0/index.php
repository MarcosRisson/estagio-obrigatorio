<?php require('./api/private/auth.php');

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Marcos Risson & Adriano Ramandelli">

    <title>AmmeShoes</title>


    <link href="./src/fonts/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="./src/css/admin.min.css" rel="stylesheet">
    <link href="./src/css/angular-confirm.min.css" rel="stylesheet">
    <link href="./src/css/app.css" rel="stylesheet">
    <link href="./src/css/bootstrap.min.css" rel="stylesheet">

    <script src="./src/lib/jquery.min.js"></script>
    <script src="./src/lib/bootstrap.min.js"></script>
    <script src="./src/lib/jquery.easing.min.js"></script>

    <script src="./src/lib/angularjs.min.js"></script>
    <script src="./src/lib/angular-ui-router.min.js"></script>
    <script src="./src/js/angular-confirm.min.js"></script>
</head>


<body id="page-top" ng-app="myApp" ng-controller="ctrlGlobal">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-black sidebar sidebar-dark accordion bg-dark " id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-img mx-2">
                    <img src="./src/img/357824915_1662506260890256_927643520464046315_n-removebg-preview.png" style=" width: 110px; height: 90px;" alt="logo">
                </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0 bg-white border-1">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="index.html" ui-sref="home">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Home</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider  bg-white my-0 ">

            <!-- Heading -->
            <div class="sidebar-heading ">
                Interface
            </div>
            <hr class="sidebar-divider  bg-white my-0 ">
            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Estoque</span>
                </a>

                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-dark-subtle py-2 collapse-inner rounded ">
                        <h6 class="collapse-header">Produtos e Vendas</h6>
                        <a class="collapse-item" ui-sref="produtos" ui-sref-active="active" data-toggle="collapse" data-target="#collapseTwo.show">Produtos</a>
                        <a class="collapse-item" ui-sref="vendas" ui-sref-active="active" data-toggle="collapse" data-target="#collapseTwo.show">Vendas</a>
                        <a class="collapse-item" ui-sref="compras" ui-sref-active="active" data-toggle="collapse" data-target="#collapseTwo.show">Compras</a>
                    </div>
                </div>
            </li>

            <hr class="sidebar-divider my-0 bg-white border-2">
            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePessoas" aria-expanded="true" aria-controls="collapsePessoas">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Pessoas</span>
                </a>
                <!-- Divider -->

                <div id="collapsePessoas" class="collapse show" aria-labelledby="collapsePessoas" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Pessoas</h6>
                        <a class="collapse-item" ui-sref="user" ui-sref-active="active" data-toggle="collapse" data-target="#collapsePessoas.show">Usuários</a>
                        <a class="collapse-item" ui-sref="people" ui-sref-active="active" data-toggle="collapse" data-target="#collapsePessoas.show">Clientes</a>
                        <a class="collapse-item" ui-sref="fornecedor" ui-sref-active="active" data-toggle="collapse" data-target="#collapsePessoas.show">Fornecedores</a>
                    </div>
                </div>
            </li>


            <!-- Divider -->
            <hr class="sidebar-divider my-0 bg-white border-2">

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Utilities</span>
                </a>
                <!-- Divider -->


                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Custom Utilities:</h6>
                        <a class="collapse-item" href="utilities-color.html">Colors</a>
                        <a class="collapse-item" href="utilities-border.html">Borders</a>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block bg-white border-2 ">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-2" id="sidebarToggle"></button>
            </div>

        </ul>

        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow" style="border-bottom: 1px #ccc solid;">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-4">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['user']['name'];  ?></span>
                                <img class="img-profile rounded-circle" src="./src/img/undraw_profile.svg">
                            </a>

                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a ng-click="logout()" class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>

                <div class="container-fluid">
                    <ui-view></ui-view>
                </div>
            </div>

        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script src="./src/js/admin.min.js"></script>
    <script src="./src/js/app.js"></script>

</body>

</html>