<?php
include 'private/connect.php';
include 'private/auth.php';
include 'private/validate.php';

//listar os usuários cadastrados
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['list'])) {

    $result = $mysqli->query('SELECT * FROM peoples');
    $rows = array();
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }

    echo json_encode($rows);
}

//listar um único item
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $mysqli->query("SELECT * FROM peoples WHERE id = $id");
    $rows = $result->fetch_assoc();
    echo json_encode($rows);
}

//inserir dados no database
if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_GET['id'])) {

   

    if ($valid) {
        echo $valid;
    } else {

        $name = $_POST['nome_completo'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $documento = $_POST['documento'];
        $genero = $_POST['genero'];
        $cep = $_POST['cep'];
        $endereco = $_POST['endereco'];
        $cidade = $_POST['cidade'];
        $bairro = $_POST['bairro'];
        $uf = $_POST['uf'];
        $status = 'A';

        $mysqli->query("INSERT INTO `peoples` 
            (`nome_completo`, `email`, `password`, `documento`, `genero`, `cep`, `endereco`, `cidade`, `bairro`,`uf`, `status`) 
            VALUES 
            ('${name}', '${email}', '${password}', '${documento}', '${genero}', '${cep}', '${endereco}','${bairro}', '${cidade}', '${uf}',   'A');
        ");

        $result = array('msg' => 'Cadastro realizado com sucesso',
            'status' => 200
        );
        echo json_encode($result);
    }
}

//update dados no database
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['id'])) {

    $valid = isValid(['nome_completo', 'email', 'password','documento', 'genero', 'cep', 'endereco', 'cidade','bairro', 'uf']);

    if ($valid) {
        echo $valid;
    } else {

        $id = $_GET['id'];
        $nome_completo = $_POST['nome_completo'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $documento = $_POST['documento'];
        $genero = $_POST['genero'];
        $cep = $_POST['cep'];
        $endereco = $_POST['endereco'];
        $cidade = $_POST['cidade'];
        $bairro = $_POST['bairro'];
        $uf = $_POST['uf'];
        $status = 'A';

        $mysqli->query("UPDATE `peoples` SET
            `nome_completo`='${nome_completo}', 
            `email`='${email}', 
            `password`='${password}', 
            `documento`='${documento}', 
            `genero`='${genero}', 
            `cep`='${cep}', 
            `endereco`='${endereco}', 
            `cidade`='${cidade}', 
            `bairro`='${bairro}', 
            `uf`='${uf}', 
            `status`='${status}'
            WHERE `id`='${id}'
        ");

        $result = array('msg' => 'Atualizado realizado com sucesso',
            'status' => 200
        );
        echo json_encode($result);
    }
}

//deletar registro no dados no database
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del'])) {

    $id = $_GET['del'];
    $mysqli->query("DELETE FROM peoples WHERE `id`='${id}'");

    $result = array('msg' => 'Deletado com sucesso',
        'status' => 200
    );
    echo json_encode($result);
}
?>
