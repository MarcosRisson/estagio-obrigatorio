<?php

header('Content-Type: application/json; charset=utf-8');

$host = 'localhost';
$user = 'root';
$pass = '';
$database = 'aulaphp';

// Estabelece a conexão com o banco de dados
$mysqli = new mysqli($host, $user, $pass, $database);

// Verifica se ocorreu algum erro na conexão
if ($mysqli->connect_error) {
    $response = array(
        'msg' => 'Erro na conexão com o banco de dados: ' . $mysqli->connect_error,
        'status' => 500
    );

    echo json_encode($response);
    exit;
}

// Configuração adicional para garantir caracteres UTF-8
$mysqli->set_charset("utf8");

// Restante do seu código aqui

?>
